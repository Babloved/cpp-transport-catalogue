#include "domain.h"

using namespace std;
